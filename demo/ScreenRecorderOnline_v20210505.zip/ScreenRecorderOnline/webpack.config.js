const path = require('path');
const { VueLoaderPlugin } = require('vue-loader')

module.exports = {
    entry: path.join(__dirname, "src", "app", "app.js"),
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },
    plugins: [
        // make sure to include the plugin!
        new VueLoaderPlugin()
    ]
}