import SimpleCommand from "../../libs/puremvc/SimpleCommand";
import Constants from "../Constants";

export default class ReloadVideos extends SimpleCommand{
    async execute(){
        let dbP = this.facade.retrieveProxy(Constants.ProxyNames.INDEXEDDB_PROXY);
        dbP.reloadRecordedVideos();
    }
}