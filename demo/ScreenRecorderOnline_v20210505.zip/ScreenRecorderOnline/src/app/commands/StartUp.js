import SimpleCommand from "../../libs/puremvc/SimpleCommand";
import Constants from "../Constants";

export default class StartUp extends SimpleCommand {

    execute(notification) {
        console.debug(notification);

        this.sendNotification(Constants.Commands.MOUNT_VUE_APP);
    }
}