import SimpleCommand from "../../libs/puremvc/SimpleCommand"
import DateHelper from "../../commons/DateHelper";
import Constants from "../Constants";

export default class RecordScreen extends SimpleCommand {

    execute(msg) {

        switch (msg.type) {
            case RecordScreen.COMMAND_TYPE_START:
                if (!RecordScreen.__currentRecorder) {
                    RecordScreen.__currentVideoId = DateHelper.getReadableTimestamp() + "_" + Date.now();
                    let stream = msg.body;
                    RecordScreen.__currentStream = stream;
                    RecordScreen.__currentRecorder = new MediaRecorder(stream, { mimeType: Constants.MediaRecorder.MIME_TYPE });
                    RecordScreen.__currentRecorder.ondataavailable = this.ondataavailable_handler.bind(this);
                    RecordScreen.__currentRecorder.onstop = this.recorderStopedHandler.bind(this);

                    RecordScreen.__currentRecorder.start(Constants.MediaRecorder.TIME_SPLIT);
                    this.sendNotification(Constants.Commands.RECORD_SCREEN_STARTED, { video_id: RecordScreen.__currentVideoId });
                }
                break
            case RecordScreen.COMMAND_TYPE_STOP:
                if (RecordScreen.__currentRecorder) {
                    RecordScreen.__currentRecorder.stop();
                    RecordScreen.__currentRecorder = null;
                }
                break
        }
    }

    recorderStopedHandler(e) {
        if (RecordScreen.__currentStream) {
            for (let t of RecordScreen.__currentStream.getTracks()) {
                t.stop();
            }
        }

        RecordScreen.__currentStream = null;
        this.sendNotification(Constants.Commands.RECORD_SCREEN_STOPPED, { video_id: RecordScreen.__currentVideoId });
        this.sendNotification(Constants.Commands.RELOAD_VIDEOS);
    }

    ondataavailable_handler(e) {
        let dbProxy = this.facade.retrieveProxy(Constants.ProxyNames.INDEXEDDB_PROXY);
        // console.debug(e);
        dbProxy.saveData(RecordScreen.__currentVideoId, e.data, e.timecode || e.timeStamp);
    }
}


RecordScreen.COMMAND_TYPE_START = "start";
RecordScreen.COMMAND_TYPE_STOP = "stop";
RecordScreen.isRecording = () => RecordScreen.__currentRecorder