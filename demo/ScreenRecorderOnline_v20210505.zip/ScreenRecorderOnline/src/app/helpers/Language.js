import Facade from "../../libs/puremvc/Facade";
import Constants from "../Constants";

const Language = {
    getLabel(text) {
        return Facade.getInstance(Constants.FacadeNames.MAIN_FACADE).retrieveProxy(Constants.ProxyNames.LANGUAGE_PROXY).getLabel(text);
    }
};

export default Language;