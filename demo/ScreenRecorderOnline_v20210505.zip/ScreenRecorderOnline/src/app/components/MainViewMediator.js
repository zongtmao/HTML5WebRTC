import Mediator from "../../libs/puremvc/Mediator"
import Constants from "../Constants"
import Dialog from "../../commons/dialogs/Dialog"
import Language from "../helpers/Language"
import MainViewEvents from "./MainViewEvents"
import RecordScreen from "../commands/RecordScreen"

export default class MainViewMediator extends Mediator {

    constructor(view) {
        super(Constants.MediatorNames.MAIN_VIEW_MEDIATOR, view);

        this.viewComponent.$on(MainViewEvents.REQUEST_TO_RECORD_STREAM, s => this.sendNotification(Constants.Commands.RECORD_SCREEN, s, RecordScreen.COMMAND_TYPE_START));
        this.viewComponent.$on(MainViewEvents.REQUEST_TO_STOP_RECORD, () => this.sendNotification(Constants.Commands.RECORD_SCREEN, null, RecordScreen.COMMAND_TYPE_STOP));
    }

    async onRegister() {
        try {
            // >>>>>>>>>>>>>>>>
            // The code here try to get the permission from user for visiting microphone, and the stop the devices
            // Without this the function navigator.mediaDevices.enumerateDevices will return devices with no labels
            let s = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
            for (let t of s.getTracks()) {
                t.stop();
            }
            // <<<<<<<<<<<<<<<<

            this.updateDevicesList();
            navigator.mediaDevices.ondevicechange = this.mediaDevicesChangeHandler.bind(this);
        } catch (e) {
            console.warn(e);
            Dialog.showMessageDialog(Language.getLabel("We can not use your microphone without your permission, please allow to use your microphone and then reload this page."));
        }
    }

    mediaDevicesChangeHandler(e) {
        this.updateDevicesList();
    }

    async updateDevicesList() {
        let devices = await navigator.mediaDevices.enumerateDevices();
        this.viewComponent.setDevices(devices.filter(d => d.kind == 'audioinput'));
    }

    onRemove() {
        navigator.mediaDevices.ondevicechange = null;
    }

    listNotificationInterests() {
        return [Constants.Commands.RECORD_SCREEN_STOPPED]
    }

    async handleNotification(notification) {
        switch (notification.name) {
            case Constants.Commands.RECORD_SCREEN_STOPPED:
                let theName = await Dialog.showInputDialog(Language.getLabel("Record completed, please name it"), {
                    labelCancel: Language.getLabel("Cancel"),
                    labelOK: Language.getLabel("OK"),
                });
                if (theName) {
                    notification.body.video_name = theName;
                    this.sendNotification(Constants.Commands.RENAME_VIDEO, notification.body);
                }
                break
        }
    }
}