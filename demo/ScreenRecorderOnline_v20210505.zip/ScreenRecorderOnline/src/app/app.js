import Facade from "../libs/puremvc/Facade"
import StartUp from "./commands/StartUp";
import AppMediator from "./components/AppMediator";
import Constants from "./Constants"
import IndexedDBProxy from "./proxies/IndexedDBProxy";
import LanguageProxy from "./proxies/LanguageProxy";
import RecordScreen from "./commands/RecordScreen";
import RenameVideo from "./commands/RenameVideo";
import ReloadVideos from "./commands/ReloadVideos";
import ExportOrPreviewVideo from "./commands/ExportOrPreviewVideo";

const facade = Facade.getInstance(Constants.FacadeNames.MAIN_FACADE);
facade.registerCommand(Constants.Commands.START_UP, StartUp);
facade.registerCommand(Constants.Commands.RECORD_SCREEN, RecordScreen);
facade.registerCommand(Constants.Commands.RENAME_VIDEO, RenameVideo);
facade.registerCommand(Constants.Commands.RELOAD_VIDEOS, ReloadVideos);
facade.registerCommand(Constants.Commands.EXPORT_OR_PREVIEW_VIDEO, ExportOrPreviewVideo);

facade.registerMediator(new AppMediator());

facade.registerProxy(new LanguageProxy());
facade.registerProxy(new IndexedDBProxy());

facade.sendNotification(Constants.Commands.START_UP);