import Proxy from "../../libs/puremvc/Proxy"
import Constants from "../Constants"

export default class LanguageProxy extends Proxy {

    constructor() {
        super(Constants.ProxyNames.LANGUAGE_PROXY, {
            "zh-CN": {
                "Audio input": "音频输入",
                "We can not use your microphone without your permission, please allow to use your microphone and then reload this page.": "在未提到您授权的情况下无法使用您的麦克风，请允许使用并刷新页面",
                "Start record screen": "开始录屏",
                "Stop": "停止",
                "Please allow ScreenRecorder to access the screen": "请允许ScreenRecorder访问你的屏幕",
                "Record completed, please name it": "录制已完成，请命名",
                "Recorded videos": "已录制的视频",
                "Nothing yet!": "暂无内容",
                "Play": "播放",
                "Export": "导出",
                "Delete": "删除",
                "Confirm to delete video": "确认删除视频",
                "Cancel": "取消",
                "OK": "确定",
                "Rename": "改名",
                "Please input a new name": "请输入新名称",
                "ScreenRecorder online": "在线版录制工具"
            },
            "en-US": {
                "Audio input": "Audio input",
                "We can not use your microphone without your permission, please allow to use your microphone and then reload this page.": "We can not use your microphone without your permission, please allow to use your microphone and then reload this page.",
                "Start record screen": "Start record screen",
                "Stop": "Stop",
                "Please allow ScreenRecorder to access the screen": "Please allow ScreenRecorder to access the screen",
                "Record completed, please name it": "Record completed, please name it",
                "Recorded videos": "Recorded videos",
                "Nothing yet!": "Nothing yet!",
                "Play": "Play",
                "Export": "Export",
                "Delete": "Delete",
                "Confirm to delete video": "Confirm to delete video",
                "Cancel": "Cancel",
                "OK": "OK",
                "Rename": "Rename",
                "Please input a new name": "Please input a new name",
                "ScreenRecorder online": "ScreenRecorder online"
            }
        })


    }

    getLabel(text) {
        let lp = this.data[navigator.language];
        return lp && lp[text] ? lp[text] : text
    }
}