<template>
  <div style="flex: 1; overflow: auto; margin-top: 0.5rem" class="card">
    <div class="card-header font-weight-bold">{{ labelVideoList }}</div>
    <div v-if="recordedVideos.length" style="flex: 1; overflow: auto">
      <table class="table">
        <tbody>
          <tr
            v-for="(v, index) in recordedVideos"
            :key="index"
            class="video-row"
          >
            <td style="word-break: break-all; position: relative">
              <div>
                {{ v.video_name || v.video_id }}

                <div
                  class="op-buttons btn-group"
                  role="group"
                  style="position: absolute; right: 0.5rem; top: 0.3rem"
                >
                  <button
                    type="button"
                    class="btn btn-dark"
                    @click="btnPreviewClicked"
                    :data-video_id="v.video_id"
                  >
                    <i class="bi bi-play-fill" style="pointer-events: none"></i>
                    {{ labelPlay }}
                  </button>
                  <button
                    type="button"
                    class="btn btn-dark"
                    @click="btnExportClicked"
                    :data-video_id="v.video_id"
                  >
                    <i class="bi bi-download" style="pointer-events: none"></i>
                    {{ labelExport }}
                  </button>
                  <button
                    type="button"
                    class="btn btn-dark"
                    @click="btnRenameClicked"
                    :data-video_id="v.video_id"
                  >
                    <i class="bi bi-pencil" style="pointer-events: none"></i>
                    {{ labelRename }}
                  </button>
                  <button
                    type="button"
                    class="btn btn-danger"
                    :data-video_id="v.video_id"
                    :data-video_name="v.video_name"
                    @click="btnDeleteClicked"
                  >
                    <i class="bi bi-trash" style="pointer-events: none"></i>
                    {{ labelDelete }}
                  </button>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-else style="padding: 0.5rem">
      {{ labelNothingYet }}
    </div>
  </div>
</template>

<script>
import Dialog from "../../commons/dialogs/Dialog";
import Language from "../helpers/Language";
import RecordedVideoListMediator from "./RecordedVideoListMediator";
import Constants from "../Constants";

export default {
  props: ["facade"],
  data() {
    return {
      recordedVideos: [],
      labelVideoList: Language.getLabel("Recorded videos"),
      labelNothingYet: Language.getLabel("Nothing yet!"),
      labelPlay: Language.getLabel("Play"),
      labelExport: Language.getLabel("Export"),
      labelDelete: Language.getLabel("Delete"),
      labelRename: Language.getLabel("Rename"),
    };
  },

  mounted() {
    this.facade.registerMediator(new RecordedVideoListMediator(this));
  },

  destroyed() {
    this.facade.removeMediator(
      Constants.MediatorNames.RECORDED_VIDEO_LIST_MEDIATOR
    );
  },

  methods: {
    btnPreviewClicked(e) {
      this.facade.sendNotification(Constants.Commands.EXPORT_OR_PREVIEW_VIDEO, {
        video_id: e.target.dataset.video_id,
        mode: "preview",
      });
    },

    btnExportClicked(e) {
      this.facade.sendNotification(Constants.Commands.EXPORT_OR_PREVIEW_VIDEO, {
        video_id: e.target.dataset.video_id,
        mode: "download",
      });
    },

    async reloadVideos(grouped) {
      while (this.recordedVideos.length) {
        this.recordedVideos.pop();
      }

      for (let [k, v] of grouped) {
        this.recordedVideos.splice(0, 0, v);
      }

      console.debug("VideoLibrary reloaded", grouped);
    },

    async btnDeleteClicked(e) {
      let video_id = e.target.dataset.video_id;
      if (
        await Dialog.showConfirmDialog(
          Language.getLabel("Confirm to delete video") +
            ` <span class="font-weight-bold">${
              e.target.dataset.video_name || video_id
            }</span>`,
          "",
          {
            labelCancel: Language.getLabel("Cancel"),
            labelOK: Language.getLabel("OK"),
          }
        )
      ) {
        let p = this.facade.retrieveProxy(Constants.ProxyNames.INDEXEDDB_PROXY);
        await p.deleteVideo(video_id);
        this.facade.sendNotification(Constants.Commands.RELOAD_VIDEOS);
      }
    },

    async btnRenameClicked(e) {
      let theName = await Dialog.showInputDialog(
        Language.getLabel("Please input a new name"),
        {
          labelCancel: Language.getLabel("Cancel"),
          labelOK: Language.getLabel("OK"),
        }
      );
      if (theName) {
        this.facade.sendNotification(Constants.Commands.RENAME_VIDEO, {
          video_id: e.target.dataset.video_id,
          video_name: theName,
        });
      }
    },
  },
};
</script>

<style scoped>
.video-row .op-buttons {
  display: none;
}

.video-row:hover .op-buttons {
  display: inline-flex;
}
</style>