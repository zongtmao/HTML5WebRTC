import Mediator from "../../libs/puremvc/Mediator"
import Constants from "../Constants"
import Language from "../helpers/Language";
import App from "./App"

export default class AppMediator extends Mediator {

    constructor() {
        super(Constants.MediatorNames.APP_MEDIATOR, App);
    }

    listNotificationInterests() {
        return [Constants.Commands.MOUNT_VUE_APP]
    }

    handleNotification(notification) {
        switch (notification.name) {
            case Constants.Commands.MOUNT_VUE_APP:
                document.title = Language.getLabel("ScreenRecorder online");
                this.viewComponent.mountToBody();
                break;
        }
    }
}