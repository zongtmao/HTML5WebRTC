import Mediator from "../../libs/puremvc/Mediator";
import Constants from "../Constants"

export default class RecordedVideoListMediator extends Mediator {
    constructor(view) {
        super(Constants.MediatorNames.RECORDED_VIDEO_LIST_MEDIATOR, view);
    }

    onRegister() {
        this.sendNotification(Constants.Commands.RELOAD_VIDEOS);
    }

    listNotificationInterests() {
        return [Constants.Commands.RECORDED_VIDEOS_RELOADED];
    }

    handleNotification(notification) {
        console.debug(notification);
        switch (notification.name) {
            case Constants.Commands.RECORDED_VIDEOS_RELOADED:
                this.viewComponent.reloadVideos(notification.body);
                break;
        }
    }
}