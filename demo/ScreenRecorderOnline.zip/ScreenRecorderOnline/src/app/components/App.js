import MainView from "./MainView.vue"
import "./AppStyle.css"

const App = new Vue({
    components: { MainView },
    template: "<main-view/>",
    methods: {
        mountToBody() {
            let el = document.createElement("div");
            document.body.appendChild(el);
            this.$mount(el);
        }
    }
});

export default App;