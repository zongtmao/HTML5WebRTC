<template>
  <div
    style="
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      padding: 0.5rem;
    "
  >
    <div style="display: flex; flex-direction: row; align-items: center">
      <div style="margin-right: 0.5rem" class="font-weight-bold">
        {{ audioInputLabel }}
      </div>
      <select style="margin-right: 0.5rem" v-model="selectedDeviceIndex">
        <option
          v-for="(d, index) in devices"
          :key="d.deviceId"
          :data-index="index"
          :value="index"
        >
          {{ d.label || d.deviceId }}
        </option>
      </select>

      <button
        type="button"
        class="btn btn-danger"
        v-if="!recording"
        @click="btnStartRecordClicked"
      >
        <i class="bi bi-record-circle"></i> {{ labelStartRecordScreen }}
      </button>
      <button
        type="button"
        class="btn btn-danger"
        v-else
        @click="btnStopRecordClicked"
      >
        <i class="bi bi-square-fill"></i> {{ labelStop }}
      </button>
    </div>
    <recorded-video-list :facade="facade"></recorded-video-list>
  </div>
</template>

<script>
import Facade from "../../libs/puremvc/Facade";
import Constants from "../Constants";
import MainViewMediator from "./MainViewMediator";
import Language from "../helpers/Language";
import Dialog from "../../commons/dialogs/Dialog";
import MainViewEvents from "./MainViewEvents";
import RecordedVideoList from "./RecordedVideoList.vue";

export default {
  components: {
    RecordedVideoList,
  },
  data() {
    let facade = Facade.getInstance(Constants.FacadeNames.MAIN_FACADE);
    return {
      facade,
      audioInputLabel: Language.getLabel("Audio input"),
      labelStartRecordScreen: Language.getLabel("Start record screen"),
      labelStop: Language.getLabel("Stop"),
      recording: false,
      devices: [],
      selectedDeviceIndex: 0,
      videos: [],
    };
  },

  methods: {
    setDevices(devices) {
      console.debug(devices);
      while (this.devices.length) {
        this.devices.pop();
      }
      this.devices.push(...devices);
      this.selectedDeviceIndex = 0;
    },

    async btnStartRecordClicked() {
      let stream = await navigator.mediaDevices.getUserMedia({
        video: false,
        audio: this.devices[this.selectedDeviceIndex],
      });

      try {
        let screenStream = await navigator.mediaDevices.getDisplayMedia();
        for (let t of screenStream.getTracks()) {
          stream.addTrack(t);
        }

        this.$emit(MainViewEvents.REQUEST_TO_RECORD_STREAM, stream);
        this.recording = true;
      } catch (err) {
        Dialog.showMessageDialog(
          Language.getLabel("Please allow ScreenRecorder to access the screen")
        );
      }
    },

    btnStopRecordClicked(e) {
      this.$emit(MainViewEvents.REQUEST_TO_STOP_RECORD);
      this.recording = false;
    },
  },

  mounted() {
    this.facade.registerMediator(new MainViewMediator(this));
  },

  destroyed() {
    this.facade.removeMediator(Constants.MediatorNames.MAIN_VIEW_MEDIATOR);
  },
};
</script>