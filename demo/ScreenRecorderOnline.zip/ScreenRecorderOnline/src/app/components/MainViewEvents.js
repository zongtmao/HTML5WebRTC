const MainViewEvents = {
    REQUEST_TO_RECORD_STREAM: "requesttorecordstream",
    REQUEST_TO_STOP_RECORD: "requesttostoprecord"
}

export default MainViewEvents;