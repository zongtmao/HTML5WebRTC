import SimpleCommand from "../../libs/puremvc/SimpleCommand";
import Constants from "../Constants";

export default class RenameVideo extends SimpleCommand {
    async execute(notification) {
        let dbP = this.facade.retrieveProxy(Constants.ProxyNames.INDEXEDDB_PROXY);
        await dbP.renameVideo(notification.body.video_id, notification.body.video_name);
        this.sendNotification(Constants.Commands.RELOAD_VIDEOS);
    }
}