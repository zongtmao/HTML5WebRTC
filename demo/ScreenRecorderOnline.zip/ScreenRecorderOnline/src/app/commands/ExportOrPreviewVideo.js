import SimpleCommand from "../../libs/puremvc/SimpleCommand";
import Constants from "../Constants";

class ExportOrPreviewVideo extends SimpleCommand {
    execute(notification) {
        super.execute(notification);

        let ip = this.facade.retrieveProxy(Constants.ProxyNames.INDEXEDDB_PROXY);
        ip.exportVideo(notification.body.video_id, notification.body.mode);
    }
}

export default ExportOrPreviewVideo;