const Constants = {
    FacadeNames: {
        MAIN_FACADE: "MainFacade"
    },

    Commands: {
        START_UP: "StartUp",
        MOUNT_VUE_APP: "mountVueApp",
        RECORD_SCREEN: "recordScreen",
        RECORD_SCREEN_STARTED: "recordScreenStarted",
        RECORD_SCREEN_STOPPED: "recordScreenStopped",
        RECORDED_VIDEOS_RELOADED: "recordedVideosReloaded",
        RENAME_VIDEO: "renameVideo",
        RELOAD_VIDEOS: "reloadVideos",
        EXPORT_OR_PREVIEW_VIDEO: "ExportOrPreviewVideo"
    },

    MediatorNames: {
        APP_MEDIATOR: "AppMediator",
        MAIN_VIEW_MEDIATOR: "MainViewMediator",
        RECORDED_VIDEO_LIST_MEDIATOR: "RecordedVideoListMediator"
    },

    ProxyNames: {
        LANGUAGE_PROXY: "LanguageProxy",
        INDEXEDDB_PROXY: "IndexedDBProxy"
    },

    IndexedDBName: "ScreenRecorderOnline",

    MediaRecorder: { MIME_TYPE: 'video/webm; codecs="opus,vp8"', TIME_SPLIT: 1000 }
};

export default Constants;