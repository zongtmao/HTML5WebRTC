const Dialog = {
  showLoading(msg) {
    return $(`<div class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="spinner-border" role="status">
          <span class="sr-only">Loading...</span>
        </div>
      </div>
      <div class="modal-body">
        <p>${msg}</p>
      </div>
    </div>
  </div>
</div>`).modal({
      keyboard: false,
      backdrop: "static",
    }).appendTo(document.body).on("hide.bs.modal", function (e) {
      $(this).remove();
    });
  },

  showMessageDialog(msg, title = "", closeCallback, closeBtnClass = "btn-danger") {
    return $(`<div class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">${title}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ${msg}
      </div>
      <div class="modal-footer">
        <button type="button" class="btn ${closeBtnClass}" data-dismiss="modal">关闭</button>
      </div>
    </div>
  </div>
</div>`).modal({
      keyboard: true,
      backdrop: true,
    }).appendTo(document.body).on("hide.bs.modal", function (e) {
      $(this).remove();
      if (closeCallback) {
        closeCallback();
      }
    });
  },

  async showConfirmDialog(msg, title = "", options = { labelCancel: "取消", labelOK: "确定" }) {
    return new Promise(resolve => {
      let returned = false;
      let d = $(`<div class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">${title}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ${msg}
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">${options.labelCancel || "取消"}</button>
        <button type="button" class="btn btn-primary btn-confirm">${options.labelOK || "确定"}</button>
      </div>
    </div>
  </div>
</div>`).modal({
        keyboard: true,
        backdrop: true,
      }).appendTo(document.body);
      d.on("hide.bs.modal", function (e) {
        $(this).remove();
        if (!returned) {
          returned = true;
          resolve(false);
        }
      });
      d.find(".btn-confirm").click(function () {
        returned = true;
        resolve(true);
        d.modal("hide");
      });
    });
  },

  async showInputDialog(title = "", options = { labelCancel: "取消", labelOK: "确定" }) {
    return new Promise(resolve => {
      let returned = false;
      let d = $(`<div class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">${title}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" class="textinput form-control">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">${options.labelCancel || "取消"}</button>
        <button type="button" class="btn btn-primary btn-confirm">${options.labelOK || "确定"}</button>
      </div>
    </div>
  </div>
</div>`).modal({
        keyboard: true,
        backdrop: "static",
      }).appendTo(document.body);
      d.on("hide.bs.modal", function (e) {
        $(this).remove();
        if (!returned) {
          returned = true;
          resolve("");
        }
      });

      d.find(".btn-confirm").click(function () {
        returned = true;
        resolve(d.find(".textinput").val());
        d.modal("hide");
      });
    });
  },

  previewImage(imageSrc) {
    return $(`<div class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">图片预览</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="text-align:center">
          <img src="${imageSrc}" style="max-width:80%;">
        </div>
      </div>
    </div>
  </div>`).modal({
      keyboard: true,
      backdrop: true,
    }).appendTo(document.body).on("hide.bs.modal", function (e) {
      $(this).remove();
    });
  },

  previewMediaStream(stream, title = "") {
    let d = $(`<div class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header" style="position:relative">
        <h5 class="modal-title">${title || '视频预览'}</h5>
        <button class='btn btn-sm btn-fullscreen' style="position:absolute;right:2.5rem;top:.9rem;"><i class="fas fa-expand-alt"></i></button>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <video style='width:100%' class='player' autoplay muted></video>
      </div>
    </div>
  </div>
</div>`).modal({
      keyboard: false,
      backdrop: "static",
    }).appendTo(document.body).on("hide.bs.modal", function (e) {
      $(this).remove();
    });

    let player = d.find(".player")[0];
    if (player) {
      player.srcObject = stream;
    }

    d.find(".btn-fullscreen").click(e => {
      if (player) {
        player.requestFullscreen();
      }
    });

    return d;
  },
};

export default Dialog;